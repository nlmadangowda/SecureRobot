#ifndef MAIN_H
#define MAIN_H
#include <Arduino.h>

void BLETask(void *pvParameters);
void MovementTask(void *pvParameters);

#endif //MAIN_H